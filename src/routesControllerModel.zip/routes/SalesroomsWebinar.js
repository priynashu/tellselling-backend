const express = require('express');
const router = express.Router();

const createDigitalSalesRoomData = require('../controllers/DigitalSalesRoomWebinarControllers/CreateSalesroom') ;
// const saveDigitalSalesRoomData= require("../controllers/DigitalSalesRoomWebinarControllers")
router.post(`/create` , createDigitalSalesRoomData);
// router.post(`/update` , saveDigitalSalesRoomData);

module.exports = router ;   