const express = require('express');
const router = express.Router();

const createDigitalSalesRoomData = require('../controllers/DigitalSalesRoomControllers/CreateSalesroom') ;
const saveDigitalSalesRoomData = require('../controllers/DigitalSalesRoomControllers/SaveSalesroom') ;
const getAllSalesrooms = require('../controllers/DigitalSalesRoomControllers/GetSalesRooms.js');
const getSingleSalesroom = require('../controllers/DigitalSalesRoomControllers/GetSingleDigitalSalesroom')
const getSingleSalesroomData = require('../controllers/DigitalSalesRoomControllers/GetDIgitalSalesRoomData')

router.post(`/create` , createDigitalSalesRoomData);
router.post(`/update` , saveDigitalSalesRoomData);
router.get('/:tenantId', getAllSalesrooms);
router.get('/:tenantId/:link', getSingleSalesroom);
router.get('/:link', getSingleSalesroomData);

module.exports = router ;   