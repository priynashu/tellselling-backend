const express = require('express');
const router = express.Router();

const createDigitalSalesRoomData = require('../controllers/DigitalSalesRoomLiveStreamControllers/CreateSalesroom') ;
const saveDigitalSalesRoomData = require('../controllers/DigitalSalesRoomControllers/SaveSalesroom') ;
const getAllSalesrooms = require('../controllers/DigitalSalesRoomLiveStreamControllers/GetSalesRooms.js');
const getSingleSalesroom = require('../controllers/DigitalSalesRoomLiveStreamControllers/GetSingleDigitalSalesroom')
const getSingleSalesroomData = require('../controllers/DigitalSalesRoomLiveStreamControllers/GetDigitalSalesRoomData')

router.post(`/create` , createDigitalSalesRoomData);
router.post(`/update` , saveDigitalSalesRoomData);
router.get('/:tenantId', getAllSalesrooms);
router.get('/:tenantId/:link', getSingleSalesroom);
router.get('/get-salesroom-data/:link', getSingleSalesroomData);

module.exports = router ;   