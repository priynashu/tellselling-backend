const express = require('express');
const router = express.Router();
const upgradePlan = require("../controllers/Billing/upgradePlan")
const getPlan = require("../controllers/Billing/getPlan")
const stripePayment = require("../controllers/Billing/stripePayment")
router.post(`/create` ,upgradePlan) ;
router.get(`/:tenantId`,getPlan);
router.post(`/payment`,stripePayment)

module.exports = router ;  