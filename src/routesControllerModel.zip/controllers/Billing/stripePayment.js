const Billings = require('../../models/Billing');
const { v4: uuidv4 } = require('uuid');
const stripe = require("stripe")("sk_test_51KZUNUSJJzWspg9OUwofycQuBbrPQ6THsZLpLlPD7q2JQVNEoKTEtmdlQD6WdGFlM8BqdqPAgnbmxeXUy8idQdr9003FsJY5pL")
const YOUR_DOMAIN = 'http://localhost:8000';
// const elements = stripe.elements()
// const CardElement = elements.create('card')
const stripePayment = async (req, res) => {
//     try{
//     const {token,product} = req.body
//     stripe.customers.create({ 
//         email: token.email, 
//         source: token.id, 
//         name: 'priyanshu shah', 
//         address: { 
//             line1: 'TC 9/4 Old MES colony', 
//             postal_code: '110092', 
//             city: 'New Delhi', 
//             state: 'Delhi', 
//             country: 'India', 
//         } 
//     }) 
//     .then((customer) => { 

//         return stripe.charges.create({ 
//             amount: 70 *100,
//             description: 'Web Development Product', 
//             currency: 'USD', 
//             customer: customer.id 
//         }); 
//     }) 
//     .then((charge) => { 
//         res.send("Success") // If no error occurs 
//     }) 
// }
// catch(err){
//     res.send("error is",err)    // If some error occurs 
// }
    
try {
    console.log("inside try");
        const {product,paymentMethod} = req.body
        // console.log(req.body);
    const payment = await stripe.paymentIntents.create({
      amount: product.price*100,
      currency: "USD",
      description: `You Purchased ${product.name}`,
      payment_method: paymentMethod.id,
      confirm: true,
    });
    console.log("stripe-routes.js 19 | payment", payment);
    res.json({
      message: "Payment Successful",
      success: true,
    });
  } catch (error) {
    console.log("stripe-routes.js 17 | error", error);
    res.json({
      message: "Payment Failed",
      success: false,
    });
  }
     

    
};
 
module.exports = stripePayment; 