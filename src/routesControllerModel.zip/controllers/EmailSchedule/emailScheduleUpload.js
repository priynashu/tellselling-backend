const EmailSchedules = require('../../models/EmailSchedule');
const schedule = require('node-schedule')
const uploadSchedule = async (req, res) => {
    // const { tenantId } = req.params;
    // console.log("inside uplaod schedule",req.body);
    const someDate = new Date("2022-03-08T17:44:00.000+5:30")
schedule.scheduleJob(someDate,()=>{
  console.log("inside upload schedule");
})
    const subject = req.body.subject
    const date = req.body.date
    const time = req.body.time
    const tenantId = req.body.tenantId
    const fullDate= req.body.fullDate
    
    // console.log(tenantId);
    try {
        const newSchedule = await EmailSchedules.create({
            tenantId: tenantId,
            subject:subject,
            date:date,
            time:time,
            fullDate:fullDate
          });
        return res.status(200).json(newSchedule);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: 'Something went wrong' });
    }
};
 
module.exports = uploadSchedule; 